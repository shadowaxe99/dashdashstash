// JavaScript code for the main functionality of the app

// Add your code here